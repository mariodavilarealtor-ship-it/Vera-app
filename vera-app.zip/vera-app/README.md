# VER·A — Instrucciones de despliegue

## Paso 1 — Sube este código a GitHub

1. Ve a github.com
2. Crea un repositorio nuevo llamado "vera-app"
3. Sube todos estos archivos

## Paso 2 — Conecta GitHub con Vercel

1. Ve a vercel.com
2. Toca "Import Project"
3. Selecciona tu repositorio "vera-app"
4. Toca "Deploy"

## Paso 3 — Agrega tus variables de entorno en Vercel

En el dashboard de Vercel:
1. Ve a tu proyecto → Settings → Environment Variables
2. Agrega estas 3 variables:

| Variable | Valor |
|----------|-------|
| ASTROLOGY_USER_ID | Tu User ID de astrology-api.io |
| ASTROLOGY_API_KEY | Tu API Key de astrology-api.io |
| ANTHROPIC_API_KEY | Tu key de Anthropic |

## Paso 4 — Redespliega

Después de agregar las variables, toca "Redeploy" en Vercel.

¡Listo! VER·A está viva.
