// pages/api/chart.js
// Este archivo corre en el servidor — tu API key está segura aquí

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { nombre, dia, mes, anio, hora, minuto, lat, lon, tz, nombreCompleto } = req.body;

  try {
    // Llamada a Astrology API
    const response = await fetch('https://json.astrologyapi.com/v1/planets/tropical', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'authorization': 'Basic ' + Buffer.from(
          process.env.ASTROLOGY_USER_ID + ':' + process.env.ASTROLOGY_API_KEY
        ).toString('base64')
      },
      body: JSON.stringify({
        day: parseInt(dia),
        month: parseInt(mes),
        year: parseInt(anio),
        hour: parseInt(hora) || 12,
        min: parseInt(minuto) || 0,
        lat: parseFloat(lat),
        lon: parseFloat(lon),
        tzone: parseFloat(tz)
      })
    });

    if (!response.ok) {
      throw new Error('API error: ' + response.status);
    }

    const planetData = await response.json();

    // Calcular número kabbalístico del nombre
    const numKab = calcularNumeroKab(nombreCompleto || nombre);

    // Generar perfil con Claude
    const perfil = await generarPerfilClaude({
      nombre, dia, mes, anio, hora,
      planetData, numKab, nombreCompleto
    });

    res.status(200).json({ perfil, planetData, numKab });

  } catch (error) {
    console.error('Error:', error);
    // Si la API falla, generamos perfil sin datos planetarios exactos
    const numKab = calcularNumeroKab(nombreCompleto || nombre);
    const perfil = await generarPerfilClaude({
      nombre, dia, mes, anio, hora,
      planetData: null, numKab, nombreCompleto
    });
    res.status(200).json({ perfil, numKab });
  }
}

function calcularNumeroKab(nombre) {
  if (!nombre) return 1;
  const tabla = {
    a:1,b:2,c:3,d:4,e:5,f:6,g:7,h:8,i:9,
    j:1,k:2,l:3,m:4,n:5,o:6,p:7,q:8,r:9,
    s:1,t:2,u:3,v:4,w:5,x:6,y:7,z:8,
    á:1,é:5,í:9,ó:6,ú:3,ñ:5
  };
  const letras = nombre.toLowerCase().replace(/[^a-záéíóúñ]/g,'').split('');
  const suma = letras.reduce((acc, l) => acc + (tabla[l] || 0), 0);
  let resultado = suma;
  while (resultado > 9 && resultado !== 11 && resultado !== 22 && resultado !== 33) {
    resultado = String(resultado).split('').reduce((a, d) => a + parseInt(d), 0);
  }
  return resultado;
}

async function generarPerfilClaude({ nombre, dia, mes, anio, hora, planetData, numKab, nombreCompleto }) {
  const planetas = planetData ? 
    planetData.map(p => `${p.name}: ${p.sign} ${p.position?.toFixed(1)}° Casa ${p.house || '?'}`).join(', ') :
    'Datos no disponibles';

  const prompt = `Eres VER·A, sistema de autoconocimiento profundo. Tu tono es directo, cálido, sin rodeos. 
NUNCA menciones astrología, planetas, signos, chakras, kabbalah ni términos esotéricos.
Habla de patrones, energías, fuerzas y potencial humano.

DATOS:
- Nombre: ${nombre}
- Nombre completo: ${nombreCompleto || nombre}
- Fecha: ${dia}/${mes}/${anio}
- Hora: ${hora || 'aproximada'}
- Número de origen: ${numKab}
- Datos planetarios: ${planetas}

Genera el perfil VER·A. Responde SOLO con JSON válido sin markdown:

{
  "saludo": "frase personalizada 1-2 líneas conectando con su esencia",
  "fuerzas": [
    {"num":"1","nombre":"nombre de 2-3 palabras descriptivo"},
    {"num":"2","nombre":"nombre de 2-3 palabras descriptivo"},
    {"num":"3","nombre":"nombre de 2-3 palabras descriptivo"}
  ],
  "energia": [
    {"nombre":"Acción","pct":25},
    {"nombre":"Pensamiento","pct":35},
    {"nombre":"Emoción","pct":25},
    {"nombre":"Intuición","pct":15}
  ],
  "energiaDesc": "descripción del patrón energético - 1-2 líneas",
  "proposito": {
    "pasion": "qué harías aunque nadie te pagara",
    "talento": "en qué eres naturalmente bueno",
    "mision": "qué necesita el mundo de ti",
    "camino": "cómo se convierte en sustento",
    "frase": "frase poderosa que resume su propósito"
  },
  "frecuenciaOrigen": {
    "numero": ${numKab},
    "nombre": "nombre del código ${numKab}",
    "descripcion": "qué revela sobre su relación con la abundancia y bloqueos",
    "fortaleza": "su poder oculto relacionado con este número",
    "trabajo": "qué debe trabajar concretamente",
    "afirmacion": "afirmación de activación poderosa"
  },
  "potencias": [
    "potencia específica 1",
    "potencia 2",
    "potencia 3",
    "potencia 4",
    "potencia 5"
  ],
  "sombras": [
    {
      "nombre": "nombre de la sombra",
      "desc": "cómo se manifiesta concretamente",
      "trans": "cómo convertirla en fortaleza",
      "frase": "frase que golpea sin nombrar fuentes"
    },
    {"nombre":"sombra 2","desc":"","trans":"","frase":""},
    {"nombre":"sombra 3","desc":"","trans":"","frase":""}
  ],
  "vocacion": "2-3 palabras",
  "pasion_corta": "2-3 palabras",
  "mision_corta": "1 frase corta",
  "carreras": [
    {"icon":"emoji","nombre":"área","razon":"por qué encaja - 1 línea"},
    {"icon":"emoji","nombre":"área","razon":""},
    {"icon":"emoji","nombre":"área","razon":""},
    {"icon":"emoji","nombre":"área","razon":""}
  ],
  "momento": "3-4 líneas sobre qué está pasando en su vida ahora y qué oportunidad tiene",
  "momentoAccion": "qué hacer esta semana - 1 línea directa",
  "pasos": [
    {"titulo":"","desc":""},
    {"titulo":"","desc":""},
    {"titulo":"","desc":""}
  ],
  "geo": [
    {"ciudad":"Ciudad, País","para":"para qué es ideal","desc":"por qué resuena"},
    {"ciudad":"Ciudad, País","para":"","desc":""},
    {"ciudad":"Ciudad, País","para":"","desc":""},
    {"ciudad":"Ciudad, País","para":"ciudad sorpresa","desc":""}
  ],
  "frase": "frase final poderosa que resume su esencia",
  "pregunta": "pregunta transformadora que se queda en la mente"
}`;

  const claudeRes = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 2000,
      messages: [{ role: 'user', content: prompt }]
    })
  });

  const claudeData = await claudeRes.json();
  const text = claudeData.content?.map(i => i.text || '').join('') || '';
  const clean = text.replace(/```json|```/g, '').trim();
  return JSON.parse(clean);
}
