import { useState, useEffect, useRef } from "react";

const S = `
@import url('https://fonts.googleapis.com/css2?family=Cormorant:ital,wght@0,300;0,400;0,500;1,300;1,400;1,500&family=Outfit:wght@200;300;400;500;600&display=swap');

:root {
  --ink:#0F0D0A; --gold:#C4922A; --gl:rgba(196,146,42,0.18);
  --gs:rgba(196,146,42,0.09); --sand:#F9F5EE; --cream:#FDFAF4;
  --stone:#8A7968; --rust:#8B4220; --deep:#1A1208;
  --muted:#6B5E4E; --green:#2D6045; --white:#FFFFFF;
}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Outfit',sans-serif;background:var(--cream);color:var(--ink);-webkit-font-smoothing:antialiased}
.app{min-height:100vh}

/* NAV */
nav{position:fixed;top:0;left:0;right:0;z-index:200;padding:15px 28px;
  display:flex;align-items:center;justify-content:space-between;
  background:rgba(253,250,244,0.94);backdrop-filter:blur(20px);
  border-bottom:1px solid var(--gl)}
.logo{font-family:'Cormorant',serif;font-size:21px;font-weight:400;letter-spacing:5px;color:var(--ink)}
.logo em{color:var(--gold);font-style:italic}
.nav-r{font-size:9px;letter-spacing:3px;text-transform:uppercase;color:var(--stone)}

/* LANDING */
.land{min-height:100vh;display:flex;flex-direction:column;align-items:center;
  justify-content:center;padding:100px 24px 80px;text-align:center;position:relative;overflow:hidden}
.land-bg{position:absolute;inset:0;pointer-events:none;
  background:radial-gradient(ellipse 80% 55% at 50% 5%,rgba(196,146,42,0.09) 0%,transparent 62%),
  radial-gradient(ellipse 45% 35% at 88% 82%,rgba(139,66,32,0.06) 0%,transparent 52%)}
.land-ey{font-size:9px;letter-spacing:5px;text-transform:uppercase;color:var(--gold);
  font-weight:400;margin-bottom:28px;animation:up 1s ease both}
.land-h1{font-family:'Cormorant',serif;font-size:clamp(46px,8vw,82px);font-weight:300;
  line-height:1.08;color:var(--ink);margin-bottom:22px;animation:up 1s .12s ease both}
.land-h1 em{font-style:italic;color:var(--rust)}
.land-p{font-size:16px;font-weight:300;color:var(--stone);max-width:440px;
  line-height:1.9;margin-bottom:48px;animation:up 1s .24s ease both}
.btn-cta{font-family:'Outfit',sans-serif;font-size:10px;font-weight:600;
  letter-spacing:4px;text-transform:uppercase;color:var(--cream);background:var(--ink);
  border:none;padding:18px 52px;cursor:pointer;position:relative;overflow:hidden;
  transition:all .3s;animation:up 1s .36s ease both}
.btn-cta::after{content:'';position:absolute;inset:0;background:var(--rust);
  transform:translateX(-101%);transition:transform .38s ease}
.btn-cta:hover::after{transform:translateX(0)}
.btn-cta span{position:relative;z-index:1}
.land-stats{display:flex;gap:48px;margin-top:64px;flex-wrap:wrap;justify-content:center;
  animation:up 1s .48s ease both}
.stat{text-align:center}
.stat-n{font-family:'Cormorant',serif;font-size:38px;font-weight:300;color:var(--gold);line-height:1}
.stat-l{font-size:9px;letter-spacing:2px;text-transform:uppercase;color:var(--stone);margin-top:5px}

/* FORM */
.form-screen{min-height:100vh;display:flex;align-items:center;justify-content:center;
  padding:80px 24px 60px}
.form-inner{max-width:480px;width:100%}
.step-ey{font-size:9px;letter-spacing:3px;text-transform:uppercase;color:var(--gold);
  font-weight:400;margin-bottom:8px}
.step-h{font-family:'Cormorant',serif;font-size:clamp(26px,4vw,38px);font-weight:300;
  color:var(--ink);line-height:1.2;margin-bottom:6px}
.step-h em{font-style:italic;color:var(--rust)}
.step-sub{font-size:14px;font-weight:300;color:var(--stone);margin-bottom:24px;line-height:1.7}

.fbox{background:var(--white);border:1px solid var(--gl);
  box-shadow:0 10px 60px rgba(15,13,10,0.07);padding:40px;position:relative}
.fbox::before{content:'';position:absolute;top:0;left:36px;right:36px;height:1px;
  background:linear-gradient(90deg,transparent,var(--gold),transparent)}

.prog{display:flex;gap:5px;margin-bottom:28px}
.pb{height:2px;flex:1;background:var(--gl);transition:background .4s}
.pb.on{background:var(--gold)}

.fg{margin-bottom:18px}
.fl{display:block;font-size:9px;letter-spacing:2px;text-transform:uppercase;
  color:var(--stone);font-weight:400;margin-bottom:8px}
.fi{width:100%;font-family:'Outfit',sans-serif;font-size:15px;font-weight:300;
  color:var(--ink);background:var(--sand);border:1px solid var(--gl);
  padding:12px 15px;outline:none;transition:all .2s;border-radius:0;-webkit-appearance:none}
.fi:focus{border-color:var(--gold);background:var(--white)}
.fi-hint{font-size:11px;color:var(--stone);font-weight:300;margin-top:4px}

/* CITY AUTOCOMPLETE */
.city-wrap{position:relative}
.city-drop{position:absolute;top:calc(100% + 4px);left:0;right:0;
  background:var(--white);border:1px solid var(--gl);z-index:100;
  box-shadow:0 8px 32px rgba(15,13,10,0.1)}
.city-opt{padding:12px 15px;font-size:14px;font-weight:300;color:var(--ink);
  cursor:pointer;display:flex;align-items:center;gap:10px;transition:background .15s;
  border-bottom:1px solid var(--gs)}
.city-opt:last-child{border-bottom:none}
.city-opt:hover{background:var(--sand)}
.city-flag{font-size:16px}
.city-name{flex:1}
.city-country{font-size:11px;color:var(--stone)}

/* DATE PICKER — estilo rueda */
.date-wrap{display:grid;grid-template-columns:1fr 1.6fr 1.2fr;gap:8px}
.date-col{display:flex;flex-direction:column}
.date-col label{font-size:9px;letter-spacing:2px;text-transform:uppercase;
  color:var(--stone);font-weight:400;margin-bottom:6px;text-align:center}
.date-select{font-family:'Outfit',sans-serif;font-size:14px;font-weight:300;
  color:var(--ink);background:var(--sand);border:1px solid var(--gl);
  padding:12px 8px;outline:none;border-radius:0;-webkit-appearance:none;
  text-align:center;cursor:pointer;width:100%}
.date-select:focus{border-color:var(--gold);background:var(--white)}

/* HORA RANGOS */
.hora-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.hora-opt{display:flex;align-items:center;gap:10px;padding:12px 14px;
  border:1px solid var(--gl);background:var(--sand);cursor:pointer;
  transition:all .2s;font-size:13px;font-weight:300;color:var(--ink)}
.hora-opt:hover{border-color:var(--gold);background:var(--white)}
.hora-opt.sel{background:var(--ink);border-color:var(--ink);color:var(--cream)}
.hora-icon{font-size:18px;flex-shrink:0}
.hora-text{}
.hora-label{font-size:13px;font-weight:400;display:block}
.hora-range{font-size:10px;opacity:.7;display:block;margin-top:1px}

/* OPCIONES */
.opts{display:flex;flex-direction:column;gap:8px}
.opt{display:flex;align-items:center;gap:12px;padding:13px 15px;
  border:1px solid var(--gl);background:var(--sand);cursor:pointer;
  transition:all .2s;font-size:14px;font-weight:300;color:var(--ink)}
.opt:hover{border-color:var(--gold);background:var(--white)}
.opt.sel{background:var(--ink);border-color:var(--ink);color:var(--cream)}
.opt-icon{font-size:18px;flex-shrink:0;width:24px;text-align:center}
.opt-dot{width:13px;height:13px;border-radius:50%;border:1px solid var(--gl);
  flex-shrink:0;transition:all .2s}
.opt.sel .opt-dot{background:var(--gold);border-color:var(--gold)}

/* NAV BOTONES */
.fnav{display:flex;gap:10px;margin-top:22px}
.btn-back{font-family:'Outfit',sans-serif;font-size:10px;font-weight:400;
  letter-spacing:2px;text-transform:uppercase;color:var(--stone);background:none;
  border:1px solid var(--gl);padding:13px 18px;cursor:pointer;transition:all .2s}
.btn-back:hover{border-color:var(--stone);color:var(--ink)}
.btn-next{font-family:'Outfit',sans-serif;font-size:10px;font-weight:600;
  letter-spacing:3px;text-transform:uppercase;color:var(--cream);background:var(--ink);
  border:none;padding:13px 24px;cursor:pointer;flex:1;position:relative;overflow:hidden}
.btn-next:disabled{opacity:.28;cursor:not-allowed}
.btn-next::after{content:'';position:absolute;inset:0;background:var(--rust);
  transform:translateX(-101%);transition:transform .3s}
.btn-next:not(:disabled):hover::after{transform:translateX(0)}
.btn-next span{position:relative;z-index:1}

/* PRECIO */
.price-box{text-align:center;padding:20px;background:var(--sand);
  border:1px solid var(--gl);margin-top:18px}
.price-n{font-family:'Cormorant',serif;font-size:46px;font-weight:300;color:var(--gold)}
.price-l{font-size:11px;font-weight:300;color:var(--stone);margin-top:3px}
.price-note{font-size:10px;color:var(--stone);font-style:italic;margin-top:4px}

/* LOADING */
.loading{min-height:100vh;display:flex;flex-direction:column;align-items:center;
  justify-content:center;padding:40px;text-align:center}
.orb{width:84px;height:84px;border-radius:50%;border:1px solid rgba(196,146,42,0.2);
  position:relative;margin:0 auto 44px;animation:breathe 3s ease-in-out infinite}
.orb::before{content:'';position:absolute;inset:10px;border-radius:50%;
  border:1px solid rgba(196,146,42,0.4);animation:spin 4s linear infinite}
.orb::after{content:'';position:absolute;inset:23px;border-radius:50%;
  background:radial-gradient(circle,rgba(196,146,42,0.28) 0%,transparent 70%)}
.load-h{font-family:'Cormorant',serif;font-size:28px;font-weight:300;color:var(--ink);margin-bottom:6px}
.load-s{font-size:10px;letter-spacing:2px;text-transform:uppercase;color:var(--stone);margin-bottom:44px}
.load-steps{display:flex;flex-direction:column;gap:14px;width:230px;margin:0 auto}
.ls{display:flex;align-items:center;gap:12px;font-size:13px;font-weight:300;
  color:var(--ink);opacity:.14;transition:opacity .6s}
.ls.on{opacity:1}.ls.was{opacity:.42}
.ld{width:5px;height:5px;border-radius:50%;background:rgba(196,146,42,0.3);
  flex-shrink:0;transition:background .3s}
.ls.on .ld{background:var(--gold)}.ls.was .ld{background:var(--rust)}

/* RESULTS */
.results{max-width:760px;margin:0 auto;padding:80px 24px 60px}
.res-top{text-align:center;padding-bottom:48px;margin-bottom:48px;border-bottom:1px solid var(--gl)}
.res-ey{font-size:9px;letter-spacing:4px;text-transform:uppercase;color:var(--gold);
  font-weight:400;margin-bottom:16px}
.res-name{font-family:'Cormorant',serif;font-size:clamp(36px,6vw,58px);font-weight:300;
  color:var(--ink);line-height:1.12;margin-bottom:16px}
.res-name em{font-style:italic;color:var(--rust)}
.res-saludo{font-size:15px;font-weight:300;color:var(--stone);line-height:1.82;
  max-width:480px;margin:0 auto}

.sec{margin-bottom:44px}
.sec-lbl{font-size:9px;letter-spacing:3px;text-transform:uppercase;color:var(--gold);
  font-weight:400;margin-bottom:18px;display:flex;align-items:center;gap:12px}
.sec-lbl::after{content:'';flex:1;height:1px;background:var(--gl)}

/* Arquetipos */
.arqs{display:grid;grid-template-columns:repeat(3,1fr);border:1px solid var(--gl)}
.arq{padding:22px 16px;text-align:center;border-right:1px solid var(--gl)}
.arq:last-child{border-right:none}
.arq-n{font-size:8px;letter-spacing:2px;text-transform:uppercase;color:var(--stone);
  font-weight:400;margin-bottom:8px}
.arq-name{font-family:'Cormorant',serif;font-size:19px;font-weight:400;color:var(--ink)}

/* Energía */
.en-bars{display:flex;flex-direction:column;gap:14px}
.en-bar{display:flex;align-items:center;gap:14px}
.en-lbl{font-size:12px;font-weight:400;color:var(--ink);width:96px;flex-shrink:0}
.en-track{flex:1;height:3px;background:var(--gl)}
.en-fill{height:100%;background:var(--gold)}
.en-pct{font-family:'Cormorant',serif;font-size:16px;font-weight:300;
  color:var(--gold);width:34px;text-align:right}
.en-desc{font-size:13px;font-weight:300;color:var(--stone);
  line-height:1.68;font-style:italic;margin-top:14px}

/* Propósito */
.prop{background:var(--deep);padding:38px 46px;position:relative;overflow:hidden;margin-bottom:44px}
.prop::after{content:'';position:absolute;top:-60px;right:-60px;width:220px;height:220px;
  border-radius:50%;background:radial-gradient(circle,rgba(196,146,42,0.13) 0%,transparent 65%);
  pointer-events:none}
.prop-ey{font-size:9px;letter-spacing:3px;text-transform:uppercase;color:var(--gold);
  font-weight:400;margin-bottom:20px}
.prop-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px;position:relative;z-index:1}
.prop-lbl{font-size:8px;letter-spacing:2px;text-transform:uppercase;color:var(--gold);
  font-weight:400;margin-bottom:6px}
.prop-val{font-family:'Cormorant',serif;font-size:15px;font-weight:300;
  color:#F9F5EE;line-height:1.5}
.prop-frase{font-family:'Cormorant',serif;font-style:italic;
  font-size:clamp(14px,2vw,17px);font-weight:300;color:rgba(249,245,238,0.68);
  line-height:1.68;margin-top:24px;padding-top:22px;
  border-top:1px solid rgba(196,146,42,0.2);position:relative;z-index:1}

/* Potencias */
.pot-list{display:flex;flex-direction:column;gap:9px}
.pot{display:flex;align-items:flex-start;gap:14px;padding:15px 18px;
  background:var(--white);border:1px solid var(--gl);
  border-left:3px solid var(--gold);font-size:14px;font-weight:300;
  color:var(--ink);line-height:1.65}

/* Sombras */
.sombra{background:var(--white);border:1px solid var(--gl);
  border-left:3px solid var(--rust);padding:22px;margin-bottom:11px}
.som-title{font-size:13px;font-weight:500;color:var(--rust);margin-bottom:8px}
.som-desc{font-size:14px;font-weight:300;color:var(--ink);line-height:1.72;margin-bottom:12px}
.som-trans{font-size:13px;font-weight:300;color:var(--green);line-height:1.62;
  padding:11px 15px;background:rgba(45,96,69,0.05);border-left:2px solid var(--green)}
.som-quote{font-size:13px;font-style:italic;color:var(--muted);
  margin-top:10px;font-weight:300;line-height:1.6}

/* VPM */
.vpm{display:grid;grid-template-columns:repeat(3,1fr);border:1px solid var(--gl);margin-bottom:44px}
.vpm-item{background:var(--deep);padding:22px 18px;text-align:center;
  border-right:1px solid rgba(196,146,42,0.2)}
.vpm-item:last-child{border-right:none}
.vpm-lbl{font-size:8px;letter-spacing:2px;text-transform:uppercase;
  color:var(--gold);font-weight:400;margin-bottom:8px}
.vpm-val{font-family:'Cormorant',serif;font-size:14px;font-weight:300;
  color:#F9F5EE;line-height:1.5}

/* Carreras */
.carr-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:11px}
.carr{background:var(--white);border:1px solid var(--gl);padding:18px;transition:all .2s}
.carr:hover{border-color:var(--gold);transform:translateY(-2px)}
.carr-icon{font-size:22px;margin-bottom:8px}
.carr-name{font-size:13px;font-weight:500;color:var(--ink);margin-bottom:4px}
.carr-why{font-size:12px;font-weight:300;color:var(--stone);line-height:1.5}

/* Momento */
.momento{background:var(--deep);padding:34px 42px;margin-bottom:44px;
  position:relative;overflow:hidden}
.momento::after{content:'';position:absolute;top:-60px;right:-60px;width:200px;height:200px;
  border-radius:50%;background:radial-gradient(circle,rgba(196,146,42,0.1) 0%,transparent 65%);
  pointer-events:none}
.mom-ey{font-size:9px;letter-spacing:3px;text-transform:uppercase;
  color:var(--gold);font-weight:400;margin-bottom:14px}
.mom-text{font-family:'Cormorant',serif;font-style:italic;
  font-size:clamp(15px,2vw,19px);font-weight:300;color:#F9F5EE;
  line-height:1.68;position:relative;z-index:1}
.mom-action{font-size:13px;color:var(--gold);margin-top:14px;
  font-weight:300;position:relative;z-index:1}

/* Pasos */
.pasos{display:flex;flex-direction:column;gap:11px}
.paso{display:flex;gap:18px;background:var(--white);border:1px solid var(--gl);padding:19px 22px}
.paso-n{font-family:'Cormorant',serif;font-size:28px;font-weight:300;
  color:var(--gold);line-height:1;flex-shrink:0;width:22px}
.paso-title{font-size:13px;font-weight:500;color:var(--ink);margin-bottom:5px}
.paso-desc{font-size:13px;font-weight:300;color:var(--stone);line-height:1.62}

/* Frase */
.frase-final{text-align:center;padding:42px;border:1px solid var(--gl);
  background:var(--sand);margin:44px 0}
.frase-text{font-family:'Cormorant',serif;font-style:italic;
  font-size:clamp(17px,2.5vw,23px);font-weight:300;color:var(--ink);
  line-height:1.62;margin-bottom:16px}
.frase-q{font-size:14px;font-weight:300;color:var(--rust);font-style:italic}

/* Ref */
.ref{background:var(--deep);padding:42px;text-align:center;margin-top:44px}
.ref-title{font-family:'Cormorant',serif;font-size:26px;font-weight:300;
  color:#F9F5EE;margin-bottom:8px}
.ref-sub{font-size:13px;font-weight:300;color:rgba(249,245,238,0.58);
  margin-bottom:24px;line-height:1.72}
.ref-code{display:inline-block;background:rgba(196,146,42,0.1);
  border:1px dashed rgba(196,146,42,0.4);padding:11px 26px;
  font-family:'Cormorant',serif;font-size:22px;font-weight:400;
  color:var(--gold);letter-spacing:4px;margin-bottom:16px}
.btn-ghost{font-family:'Outfit',sans-serif;font-size:10px;font-weight:600;
  letter-spacing:3px;text-transform:uppercase;color:#F9F5EE;background:transparent;
  border:1px solid rgba(196,146,42,0.3);padding:12px 26px;cursor:pointer;transition:all .3s}
.btn-ghost:hover{border-color:var(--gold);color:var(--gold)}
.ref-note{font-size:10px;color:rgba(249,245,238,0.38);font-weight:300;
  margin-top:13px;font-style:italic}

.back-btn{background:none;border:none;font-family:'Outfit',sans-serif;font-size:10px;
  letter-spacing:2px;text-transform:uppercase;color:var(--stone);cursor:pointer;
  padding:0;margin-bottom:30px;transition:color .2s}
.back-btn:hover{color:var(--ink)}

@keyframes up{from{opacity:0;transform:translateY(22px)}to{opacity:1;transform:translateY(0)}}
@keyframes spin{from{transform:rotate(0)}to{transform:rotate(360deg)}}
@keyframes breathe{0%,100%{transform:scale(1);opacity:1}50%{transform:scale(.92);opacity:.7}}

@media(max-width:540px){
  .arqs,.vpm{grid-template-columns:1fr}
  .arq{border-right:none;border-bottom:1px solid var(--gl)}
  .arq:last-child{border-bottom:none}
  .vpm-item{border-right:none;border-bottom:1px solid rgba(196,146,42,0.2)}
  .vpm-item:last-child{border-bottom:none}
  .prop-grid{grid-template-columns:1fr}
  .hora-grid{grid-template-columns:1fr}
  .fbox{padding:26px}
  .prop,.momento,.ref{padding:26px}
  .date-wrap{grid-template-columns:1fr 1.4fr 1.1fr}
}
`;

// Ciudades con autocompletado
const CITIES = [
  {name:"Caracas",country:"Venezuela",flag:"🇻🇪",tz:-4},
  {name:"Valencia",country:"Venezuela",flag:"🇻🇪",tz:-4},
  {name:"Maracaibo",country:"Venezuela",flag:"🇻🇪",tz:-4},
  {name:"Barcelona",country:"Venezuela",flag:"🇻🇪",tz:-4},
  {name:"Barquisimeto",country:"Venezuela",flag:"🇻🇪",tz:-4},
  {name:"Valencia",country:"España",flag:"🇪🇸",tz:1},
  {name:"Madrid",country:"España",flag:"🇪🇸",tz:1},
  {name:"Barcelona",country:"España",flag:"🇪🇸",tz:1},
  {name:"Sevilla",country:"España",flag:"🇪🇸",tz:1},
  {name:"Miami",country:"Florida, EE.UU.",flag:"🇺🇸",tz:-5},
  {name:"Nueva York",country:"EE.UU.",flag:"🇺🇸",tz:-5},
  {name:"Los Ángeles",country:"EE.UU.",flag:"🇺🇸",tz:-8},
  {name:"Houston",country:"EE.UU.",flag:"🇺🇸",tz:-6},
  {name:"Bogotá",country:"Colombia",flag:"🇨🇴",tz:-5},
  {name:"Medellín",country:"Colombia",flag:"🇨🇴",tz:-5},
  {name:"Ciudad de México",country:"México",flag:"🇲🇽",tz:-6},
  {name:"Monterrey",country:"México",flag:"🇲🇽",tz:-6},
  {name:"Lima",country:"Perú",flag:"🇵🇪",tz:-5},
  {name:"Buenos Aires",country:"Argentina",flag:"🇦🇷",tz:-3},
  {name:"Santiago",country:"Chile",flag:"🇨🇱",tz:-4},
  {name:"Quito",country:"Ecuador",flag:"🇪🇨",tz:-5},
  {name:"La Paz",country:"Bolivia",flag:"🇧🇴",tz:-4},
  {name:"Asunción",country:"Paraguay",flag:"🇵🇾",tz:-4},
  {name:"Montevideo",country:"Uruguay",flag:"🇺🇾",tz:-3},
  {name:"San José",country:"Costa Rica",flag:"🇨🇷",tz:-6},
  {name:"Ciudad de Panamá",country:"Panamá",flag:"🇵🇦",tz:-5},
  {name:"Lisboa",country:"Portugal",flag:"🇵🇹",tz:0},
  {name:"Londres",country:"Reino Unido",flag:"🇬🇧",tz:0},
];

const HORAS = [
  {v:"manana",icon:"🌅",label:"Mañana",range:"6am — 12pm"},
  {v:"tarde",icon:"☀️",label:"Tarde",range:"12pm — 6pm"},
  {v:"noche",icon:"🌙",label:"Noche",range:"6pm — 12am"},
  {v:"madrugada",icon:"⭐",label:"Madrugada",range:"12am — 6am"},
  {v:"nose",icon:"❓",label:"No lo sé",range:"Continuamos igual"},
];

const MESES = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];

const STEPS_LOAD = ["Analizando tu mapa de origen","Identificando tus potencias","Descubriendo tus sombras","Construyendo tu propósito","Preparando tu perfil"];

// Preguntas
const Q = {
  soy:[
    {v:"actuo",icon:"⚡",l:"Actúo primero, pienso después"},
    {v:"pienso",icon:"🧠",l:"Pienso mucho antes de actuar"},
    {v:"siento",icon:"❤️",l:"Me guío más por lo que siento"},
    {v:"equilibrio",icon:"⚖️",l:"Depende del momento"},
  ],
  cuesta:[
    {v:"terminar",icon:"🏁",l:"Terminar lo que empiezo"},
    {v:"decidir",icon:"🤔",l:"Tomar decisiones"},
    {v:"creer",icon:"🙋",l:"Creer en mí mismo/a"},
    {v:"relacionar",icon:"🤝",l:"Relacionarme con otros"},
  ],
  dicen:[
    {v:"talento",icon:"👑",l:"Que tengo talento pero no lo aprovecho"},
    {v:"enfocado",icon:"🚀",l:"Que cuando me enfoco soy imparable"},
    {v:"generoso",icon:"💝",l:"Que doy mucho y recibo poco"},
    {v:"capaz",icon:"🎯",l:"Que soy muy capaz pero me complico"},
  ],
  busca:[
    {v:"fortalezas",icon:"💪",l:"Saber para qué soy bueno/a"},
    {v:"direccion",icon:"🧭",l:"Encontrar mi dirección"},
    {v:"avanzar",icon:"💡",l:"Entender por qué no avanzo"},
    {v:"carrera",icon:"🎓",l:"Saber qué estudiar o hacer"},
  ],
  momento:[
    {v:"nuevo",icon:"🌱",l:"Empezando algo nuevo"},
    {v:"estancado",icon:"😐",l:"Estancado/a hace tiempo"},
    {v:"cambio",icon:"🔄",l:"Cambiando de dirección"},
    {v:"consolidar",icon:"🏗️",l:"Consolidando lo que tengo"},
  ],
};

function generarPerfil(f) {
  const {nombre,soy,cuesta,dicen,busca,momento} = f;

  const arqMap = {
    "actuo-terminar":["El Pionero","El Iniciador","El Visionario"],
    "actuo-decidir":["El Guerrero","El Ejecutor","El Líder"],
    "pienso-terminar":["El Estratega","El Arquitecto","El Analista"],
    "pienso-creer":["El Sabio","El Observador","El Pensador"],
    "siento-relacionar":["El Sanador","El Conector","El Empático"],
    "siento-creer":["El Artista","El Soñador","El Creador"],
    "equilibrio-decidir":["El Puente","El Diplomático","El Mediador"],
    "equilibrio-terminar":["El Explorador","El Versátil","El Adaptador"],
  };
  const arqs = arqMap[`${soy}-${cuesta}`] || ["El Visionario","El Constructor","El Explorador"];

  const enMap = {
    actuo:{Acción:38,Pensamiento:24,Emoción:22,Intuición:16},
    pienso:{Acción:17,Pensamiento:44,Emoción:20,Intuición:19},
    siento:{Acción:22,Pensamiento:20,Emoción:40,Intuición:18},
    equilibrio:{Acción:26,Pensamiento:32,Emoción:26,Intuición:16},
  };
  const en = enMap[soy] || enMap.equilibrio;

  const enDesc = {
    actuo:"Eres energía en movimiento. Tu fuerza está en la acción — y tu reto es aprender a pausar sin perder impulso.",
    pienso:"Procesas el mundo en profundidad. Tu claridad mental es tu mayor activo — y tu mayor trampa cuando la usas para no actuar.",
    siento:"Tu inteligencia emocional es extraordinaria. Sientes lo que otros no ven — y eso es un superpoder cuando aprendes a usarlo con límites.",
    equilibrio:"Tienes la rara capacidad de adaptarte. Eso te hace valioso en cualquier contexto — y a veces dificulta saber exactamente quién eres.",
  };

  const potMap = {
    "talento-fortalezas":["Talento natural que otros reconocen antes que tú","Capacidad de destacar sin esfuerzo en lo que te apasiona","Don para inspirar sin proponértelo","Habilidad de ver oportunidades donde otros ven obstáculos","Potencial sin desarrollar que es tu mayor tesoro oculto"],
    "enfocado-avanzar":["Cuando te enfocas eres literalmente imparable","Intensidad que convierte metas en resultados","Capacidad de aprender rápido cualquier cosa que decidas dominar","Energía que activa a quienes te rodean","Determinación que pocos tienen cuando aparece"],
    "generoso-direccion":["Inteligencia emocional que genera confianza instantánea","Don para hacer que otros se sientan vistos y comprendidos","Lealtad y entrega que son extraordinariamente raras","Capacidad de nutrir proyectos y personas con tu energía","Corazón que atrae a quienes necesitan exactamente lo que tú das"],
    "capaz-carrera":["Capacidad analítica que resuelve lo que otros no pueden","Versatilidad que te hace valioso en múltiples contextos","Mente que ve los detalles y el panorama al mismo tiempo","Don para entender sistemas complejos con rapidez","Potencial de liderazgo que espera ser activado"],
  };
  const potKey = `${dicen}-${busca}`;
  const pots = potMap[potKey] || ["Capacidad de ver el potencial donde otros ven obstáculos","Don natural para conectar ideas y personas","Inteligencia que se adapta a cualquier contexto","Visión que anticipa lo que viene antes que los demás","Potencial de impacto que todavía no has terminado de descubrir"];

  const sombraMap = {
    terminar:{nombre:"El Iniciador que no termina",desc:"Tienes una energía extraordinaria para empezar. Las ideas te emocionan, los proyectos te activan. Pero algo pasa en el camino — cuando la novedad desaparece, la energía también. Y lo que iba a cambiar tu vida queda a medias.",trans:"El secreto no es más fuerza de voluntad — es reducir el tamaño del proyecto hasta que puedas terminarlo. Un paso pequeño terminado vale infinitamente más que diez grandes proyectos a medias.",frase:"Lo que terminas, aunque sea pequeño, construye el músculo que necesitas para terminar lo grande."},
    decidir:{nombre:"El Analizador sin fin",desc:"Tu mente puede ver todos los lados de cualquier situación — y eso que parece una ventaja se convierte en tu mayor obstáculo. Porque cuando puedes ver todo, también puedes encontrar razones para no decidir nada.",trans:"La decisión perfecta no existe. Existe la decisión que tomas con la información que tienes — y la corriges sobre la marcha. La acción imperfecta siempre supera a la inacción perfecta.",frase:"Decidir imperfecto hoy supera a decidir perfecto nunca."},
    creer:{nombre:"El que duda de su propio valor",desc:"Hay una voz interna que minimiza tus logros, que encuentra razones por las que no eres suficiente, que te convence de que otros son más capaces. Esa voz no dice la verdad — dice lo que aprendiste a creer en algún momento.",trans:"Lo que percibes en otros como fortaleza que tú no tienes — generalmente es exactamente lo que los demás ven en ti. El primer paso es dejar de necesitar pruebas externas para creer en lo que ya existe.",frase:"No necesitas permiso de nadie para ser lo que ya eres."},
    relacionar:{nombre:"El que conecta desde la distancia",desc:"Puedes ser cálido, generoso, incluso carismático — pero hay una parte tuya que mantiene distancia. Que no termina de mostrarse del todo. Que prefiere el control a la vulnerabilidad real.",trans:"La conexión genuina no requiere que te expongas sin límites — requiere que te muestres suficiente para que otros puedan encontrarte. Un paso de apertura honesta vale más que años de calidez calculada.",frase:"Las personas no se conectan con tu versión perfecta. Se conectan con tu versión real."},
  };
  const s1 = sombraMap[cuesta] || sombraMap.decidir;

  const s2map = {
    estancado:{nombre:"La zona cómoda disfrazada",desc:"Lo que llamas estancamiento a veces es una zona cómoda que ya no duele suficientemente para moverse. El problema no es que no puedas avanzar — es que todavía no decidiste que el precio de quedarte es más alto que el precio de moverte.",trans:"El cambio no ocurre cuando tienes todas las condiciones. Ocurre cuando decides que ya no puedes seguir igual. ¿Ya llegaste a ese punto?",frase:"El momento de cambiar nunca es perfecto. Pero siempre es ahora."},
    nuevo:{nombre:"El síndrome del comienzo eterno",desc:"Empezar se siente bien. Hay energía, hay posibilidad, hay esperanza. Pero hay un patrón que vale la pena observar: ¿cuántos comienzos han quedado a medias? El inicio no es el logro — la continuidad sí.",trans:"Esta vez la diferencia no está en el entusiasmo del inicio — está en el sistema que construyes para cuando el entusiasmo desaparece.",frase:"El entusiasmo te lleva a empezar. El sistema te lleva a terminar."},
    cambio:{nombre:"El miedo al salto",desc:"Estás en transición — lo que significa que ya sabes lo que dejas pero todavía no ves con claridad lo que viene. Esa incertidumbre puede paralizarte o puede ser exactamente el combustible que necesitas.",trans:"Las transiciones no se navegan con certeza — se navegan con dirección. No necesitas saber exactamente a dónde vas. Necesitas saber en qué dirección moverte.",frase:"No necesitas ver el camino completo. Solo el próximo paso."},
    consolidar:{nombre:"El perfeccionismo del último 20%",desc:"Tienes mucho construido. Pero hay algo que no termina de consolidarse — y la razón suele ser que el último 20% requiere el tipo de exposición que el resto del camino no exigía.",trans:"Lo que tienes ya es suficiente para dar el siguiente paso. El 20% que falta se construye exponiéndose, no esperando.",frase:"Ya tienes más de lo que crees. El problema no es lo que te falta — es que aún no lo usas todo."},
  };
  const s2 = s2map[momento] || s2map.estancado;

  const s3 = {nombre:"Lo que das sin recibir",desc:"Hay un patrón que aparece en muchas personas capaces — dar generosamente a otros lo que se niegan a darse a sí mismos. Tiempo, atención, paciencia, oportunidades. Lo que das afuera con facilidad, te lo niegas adentro con excusas.",trans:"Empezar a darte a ti mismo lo que le das a otros no es egoísmo — es la única forma de seguir dando sin vaciarte. El tanque vacío no alimenta a nadie.",frase:"No puedes dar lo que no tienes. Y no tienes lo que no te permites recibir."};

  const propMap = {
    "fortalezas-actuo":{pasion:"Construir y ejecutar lo que imaginas",talento:"Iniciar y activar donde otros dudan",mision:"Demostrar que se puede hacer más con menos",camino:"Emprendimiento, liderazgo, ejecución estratégica",frase:"Tu propósito no es tener éxito — es redefinir lo que significa lograrlo."},
    "direccion-pienso":{pasion:"Entender cómo funciona todo — y cómo podría funcionar mejor",talento:"Ver lo que otros ignoran en la profundidad",mision:"Crear claridad donde otros solo ven complejidad",camino:"Estrategia, análisis, consultoría, educación",frase:"Tu propósito vive donde tu mente profunda se encuentra con las necesidades reales del mundo."},
    "avanzar-siento":{pasion:"Conectar con personas a un nivel que transforma",talento:"Sentir lo que otros no pueden articular",mision:"Sanar, guiar y acompañar desde la autenticidad",camino:"Psicología, coaching, arte, comunicación humana",frase:"Tu propósito no se construye — se descubre cuando dejas de esconder lo que más te mueve."},
    "carrera-equilibrio":{pasion:"Crear soluciones que integren múltiples perspectivas",talento:"Adaptarte y encontrar el punto de equilibrio en cualquier situación",mision:"Ser el puente que conecta lo que parece opuesto",camino:"Mediación, diplomacia, diseño, negocios internacionales",frase:"Tu propósito vive en la intersección — donde nadie más puede estar porque solo tú ves los dos lados."},
  };
  const propKey = `${busca}-${soy}`;
  const prop = propMap[propKey] || {pasion:"Crear impacto real en quienes te rodean",talento:"Ver el potencial donde otros ven el problema",mision:"Ser parte del cambio que el mundo necesita ahora",camino:"Lo que te apasiona, hecho con excelencia y al servicio de otros",frase:"Tu propósito ya está en ti — solo necesita que dejes de ignorarlo."};

  const carrMap = {
    "fortalezas-talento":[{icon:"🎯",nombre:"Liderazgo y dirección",razon:"Tu talento natural para guiar es tu activo más valioso"},{icon:"💼",nombre:"Emprendimiento",razon:"Tienes el perfil exacto para crear algo tuyo"},{icon:"🎨",nombre:"Creatividad y diseño",razon:"Tu capacidad creativa necesita una plataforma"},{icon:"🗣️",nombre:"Comunicación estratégica",razon:"Tu voz tiene el peso que muchos buscan"}],
    "avanzar-enfocado":[{icon:"🚀",nombre:"Alta dirección y ejecución",razon:"Cuando te enfocas eres difícil de superar"},{icon:"📊",nombre:"Consultoría estratégica",razon:"Tu capacidad analítica resuelve lo que otros no pueden"},{icon:"💡",nombre:"Innovación y tecnología",razon:"Tu mente está diseñada para el futuro"},{icon:"🏗️",nombre:"Gestión de proyectos",razon:"Convertir visión en resultados es tu zona natural"}],
    "direccion-generoso":[{icon:"🧠",nombre:"Psicología y desarrollo humano",razon:"Tu profundidad emocional es tu herramienta principal"},{icon:"🌱",nombre:"Coaching y mentoría",razon:"Has aprendido suficiente para guiar a otros"},{icon:"❤️",nombre:"Trabajo social y comunitario",razon:"Tu corazón y tu capacidad juntos generan impacto real"},{icon:"🎓",nombre:"Educación transformadora",razon:"Tu forma de enseñar toca algo que los demás no llegan"}],
    "carrera-capaz":[{icon:"⚖️",nombre:"Derecho y negociación",razon:"Tu capacidad analítica y tu visión son perfectas aquí"},{icon:"💰",nombre:"Finanzas y estrategia",razon:"Tu mente sistemática maneja la complejidad con facilidad"},{icon:"🌐",nombre:"Negocios internacionales",razon:"Tu versatilidad es exactamente lo que el mundo global necesita"},{icon:"🔬",nombre:"Investigación y desarrollo",razon:"Tu profundidad intelectual pertenece a espacios de alto nivel"}],
  };
  const carrKey = `${busca}-${dicen}`;
  const carreras = carrMap[carrKey] || [{icon:"💡",nombre:"Innovación",razon:"Tu mente conectiva genera valor donde otros no ven nada"},{icon:"🌍",nombre:"Impacto social",razon:"Tu deseo genuino de cambio es el motor de proyectos que trascienden"},{icon:"📱",nombre:"Comunicación digital",razon:"Tu voz tiene alcance — solo falta la plataforma correcta"},{icon:"🏗️",nombre:"Construcción de proyectos",razon:"Tu capacidad de materializar ideas es tu ventaja real"}];

  const momMap = {
    estancado:"Lo que sientes como estancamiento no es el final de algo — es la señal exacta de que ya creciste más allá del espacio donde estás. No caben más ahí. La incomodidad que sientes es la presión que antecede al movimiento real.",
    nuevo:"Empezar se siente como posibilidad pura. Pero esta vez hay algo diferente — ya traes contigo todo lo que aprendiste en los intentos anteriores. Eso no es poca cosa. Eso es exactamente lo que hace que esta vez sea diferente.",
    cambio:"Las transiciones son los momentos más honestos de la vida. Lo que estás dejando atrás hizo su trabajo. Lo que viene no te pide que lo entiendas todo ahora — solo que des el siguiente paso en la dirección que ya conoces.",
    consolidar:"Tienes más construido de lo que crees. El problema no es lo que falta — es que aún no estás usando todo lo que ya tienes. Esta es la fase donde la profundidad supera a la amplitud.",
  };
  const momAcc = {
    estancado:"Esta semana — un paso en la dirección que llevas meses evitando.",
    nuevo:"Esta semana — define exactamente qué quieres que sea diferente en 90 días.",
    cambio:"Esta semana — nombra lo que estás dejando y lo que estás eligiendo. Por escrito.",
    consolidar:"Esta semana — usa una capacidad tuya que llevas tiempo sin activar.",
  };

  const pasosMap = {
    terminar:[{titulo:"El proyecto mínimo terminado",desc:"Elige algo que puedas terminar esta semana. No el proyecto grande — uno pequeño. Termínalo. Esa sensación de cierre es el músculo que necesitas para los grandes."},{titulo:"La regla del 80%",desc:"Cuando llegues al 80% de algo — para. Evalúa si el 20% restante justifica el esfuerzo. A veces el 80% ya es suficiente para lanzar."},{titulo:"Un compromiso público",desc:"Dile a alguien específico qué vas a terminar y para cuándo. El compromiso social es más poderoso que la fuerza de voluntad."}],
    decidir:[{titulo:"La regla de las 48 horas",desc:"Cualquier decisión que lleves más de 3 días pensando — tienes 48 horas para tomarla. Con la información que tienes. Sin esperar más."},{titulo:"Confía en el primer instinto",desc:"Tu primera respuesta suele ser la más honesta. Esta semana — actúa en ella antes de que la duda llegue a editarla."},{titulo:"Decide pequeño para decidir grande",desc:"Practica tomando decisiones menores rápido. Eso entrena el músculo que necesitas para cuando las decisiones sean grandes."}],
    creer:[{titulo:"El inventario real",desc:"Escribe 5 cosas en las que eres genuinamente bueno. No las que te gustaría — las que otros te han dicho o que has demostrado. Léelas en voz alta."},{titulo:"Un no consciente",desc:"Esta semana — di no a algo que normalmente aceptas para evitar incomodidad. Ese no es el primer acto de creer en tu propio criterio."},{titulo:"Actúa como si ya creyeras",desc:"No esperes sentirte listo. Actúa como lo haría alguien que ya cree en sí mismo — y el sentimiento llega después de la acción, no antes."}],
    relacionar:[{titulo:"Una conversación real",desc:"Esta semana — ten una conversación donde compartas algo que normalmente guardas. No todo — algo. La vulnerabilidad parcial es el primer paso."},{titulo:"Pide algo concreto",desc:"Pedir ayuda en algo específico activa la conexión más que cualquier charla social. Pruébalo con alguien de confianza."},{titulo:"Escucha sin preparar respuesta",desc:"En tu próxima conversación importante — escucha sin pensar en qué vas a decir. Solo escucha. Eso cambia la dinámica de cualquier relación."}],
  };
  const pasos = pasosMap[cuesta] || pasosMap.decidir;

  const fraseMap = {
    "estancado-actuo":"Tienes el motor. Solo falta decidir a dónde.",
    "nuevo-pienso":"Esta vez no empiezas desde cero — empiezas desde la experiencia.",
    "cambio-siento":"Lo que estás soltando hizo su trabajo. Lo que viene te necesita completo.",
    "consolidar-equilibrio":"Ya tienes más de lo que crees. El siguiente nivel no requiere más — requiere usarlo diferente.",
  };
  const frase = fraseMap[`${momento}-${soy}`] || "Ya tienes todo lo que necesitas para llegar donde quieres. El único paso que falta es decidir que es ahora.";

  const pregMap = {
    fortalezas:"¿Qué harías con tu vida si supieras que eso que haces tan bien tiene más valor del que crees?",
    direccion:"¿En qué dirección te moverías si supieras que no puedes fallar?",
    avanzar:"¿Qué patrón llevas repitiendo que sabes que necesitas romper — y qué te ha impedido hacerlo?",
    carrera:"¿Qué harías con tu vida si el dinero no fuera la primera pregunta?",
  };
  const pregunta = pregMap[busca] || "¿Qué cambiaría en tu vida si empezaras a tratarte con la misma generosidad con que tratas a otros?";

  const salMap = {
    "estancado-fortalezas":`${nombre}, lo que sientes como estancamiento es la señal de que ya creciste más allá de donde estás. No es el final — es el umbral.`,
    "nuevo-direccion":`${nombre}, empezar con dirección clara es completamente diferente a empezar con solo entusiasmo. Hoy estás en el primer caso.`,
    "cambio-avanzar":`${nombre}, la razón por la que no avanzas no es falta de capacidad — es un patrón que opera por debajo de lo que puedes ver. Eso está a punto de cambiar.`,
    "consolidar-carrera":`${nombre}, tienes más construido de lo que reconoces. El siguiente paso no requiere más esfuerzo — requiere más dirección.`,
  };
  const saludo = salMap[`${momento}-${busca}`] || `${nombre}, lo que está a punto de revelarse no es nuevo — es lo que siempre has sido, visto con claridad por primera vez.`;

  return {
    saludo, frase, pregunta,
    arquetipos:arqs.map((n,i)=>({num:String(i+1),nombre:n})),
    energia:Object.entries(en).map(([nombre,pct])=>({nombre,pct})),
    energiaDesc:enDesc[soy]||enDesc.equilibrio,
    proposito:prop,
    potencias:pots,
    sombras:[s1,s2,s3],
    vocacion:soy==="actuo"?"Liderar · Ejecutar · Crear":soy==="pienso"?"Analizar · Estrategizar · Resolver":soy==="siento"?"Conectar · Sanar · Guiar":"Adaptar · Integrar · Equilibrar",
    pasion:busca==="fortalezas"?"Hacer brillar lo que ya existe":busca==="direccion"?"Encontrar el camino correcto":busca==="avanzar"?"Romper lo que me detiene":"Construir el futuro desde hoy",
    mision_corta:dicen==="talento"?"Usar mi potencial antes de que caduque":dicen==="enfocado"?"Enfocarme en lo que realmente importa":dicen==="generoso"?"Dar desde la abundancia, no desde el vacío":"Simplificar mi poder para multiplicar mi impacto",
    carreras, momento:momMap[momento]||momMap.estancado,
    momentoAccion:momAcc[momento]||momAcc.estancado, pasos,
  };
}

export default function VeraApp() {
  const [screen, setScreen] = useState("landing");
  const [step, setStep] = useState(1);
  const [loadStep, setLoadStep] = useState(-1);
  const [perfil, setPerfil] = useState(null);
  const [copied, setCopied] = useState(false);
  const [cityQ, setCityQ] = useState("");
  const [cityQH, setCityQH] = useState("");
  const [cityDrop, setCityDrop] = useState(false);
  const [cityDropH, setCityDropH] = useState(false);
  const [form, setForm] = useState({
    nombre:"",dia:"",mes:"",anio:"",hora:"",horaExacta:"",
    ciudad:"",ciudadHoy:"",
    soy:"",cuesta:"",dicen:"",busca:"",momento:""
  });

  const set = (k,v) => setForm(f=>({...f,[k]:v}));

  const filteredCities = CITIES.filter(c =>
    cityQ.length>1 && (c.name.toLowerCase().includes(cityQ.toLowerCase()) || c.country.toLowerCase().includes(cityQ.toLowerCase()))
  ).slice(0,5);

  const filteredCitiesH = CITIES.filter(c =>
    cityQH.length>1 && (c.name.toLowerCase().includes(cityQH.toLowerCase()) || c.country.toLowerCase().includes(cityQH.toLowerCase()))
  ).slice(0,5);

  // Allow free text cities
  useEffect(() => {
    if (cityQ.length > 1 && !form.ciudad) set("ciudad", cityQ);
  }, [cityQ]);

  useEffect(() => {
    if (cityQH.length > 1 && !form.ciudadHoy) set("ciudadHoy", cityQH);
  }, [cityQH]);

  const Opt = ({group,v,l,icon}) => (
    <div className={`opt ${form[group]===v?"sel":""}`} onClick={()=>set(group,v)}>
      {icon && <span className="opt-icon">{icon}</span>}
      {!icon && <div className="opt-dot"/>}
      {l}
    </div>
  );

  const dias = Array.from({length:31},(_,i)=>i+1);
  const anios = Array.from({length:100},(_,i)=>new Date().getFullYear()-i);

  const can1 = form.nombre && form.dia && form.mes && form.anio && (form.ciudad || cityQ.length>1) && (form.hora || form.horaExacta);
  const can2 = form.soy && form.cuesta && (form.ciudadHoy || cityQH.length>1);
  const can3 = form.dicen && form.busca && form.momento;

  const startLoad = () => {
    setScreen("loading");
    let i=0; setLoadStep(0);
    const t = setInterval(()=>{ i++; setLoadStep(i); if(i>=STEPS_LOAD.length) clearInterval(t); },700);
    setTimeout(()=>{ setPerfil(generarPerfil(form)); setScreen("results"); },4000);
  };

  const refCode = `VERA${Math.random().toString(36).substr(2,5).toUpperCase()}`;

  return (
    <div className="app">
      <style>{S}</style>
      <nav>
        <div className="logo">VER<em>·</em>A</div>
        <div className="nav-r">{screen==="results"?"Tu perfil":"Tu mapa personal"}</div>
      </nav>

      {/* LANDING */}
      {screen==="landing" && (
        <div className="land">
          <div className="land-bg"/>
          <div className="land-ey">Autoconocimiento · Propósito · Dirección</div>
          <h1 className="land-h1">Ya tienes todo<br/>lo que necesitas.<br/><em>Solo falta verlo.</em></h1>
          <p className="land-p">VER·A revela tus talentos reales, tus sombras y el camino concreto hacia lo que realmente quieres — con una precisión que te va a sorprender.</p>
          <button className="btn-cta" onClick={()=>setScreen("form")}><span>Descubrir mi perfil</span></button>
          <div className="land-stats">
            <div className="stat"><div className="stat-n">3</div><div className="stat-l">Arquetipos</div></div>
            <div className="stat"><div className="stat-n">$3.33</div><div className="stat-l">Acceso total</div></div>
            <div className="stat"><div className="stat-n">∞</div><div className="stat-l">Único como tú</div></div>
          </div>
        </div>
      )}

      {/* FORM */}
      {screen==="form" && (
        <div className="form-screen">
          <div className="form-inner">
            <div className="step-ey">Paso {step} de 3</div>
            <h2 className="step-h">Cuéntanos<br/><em>lo esencial</em></h2>
            <p className="step-sub">Unas preguntas rápidas para construir tu mapa personal.</p>
            <div className="fbox">
              <div className="prog">{[1,2,3].map(n=><div key={n} className={`pb ${n<step?"on":""}`}/>)}</div>

              {/* PASO 1 */}
              {step===1 && (
                <div>
                  <div className="fg">
                    <label className="fl">¿Cómo te llamas?</label>
                    <input className="fi" placeholder="Tu nombre" value={form.nombre} onChange={e=>set("nombre",e.target.value)}/>
                  </div>

                  <div className="fg">
                    <label className="fl">¿Cuándo naciste?</label>
                    <div className="date-wrap">
                      <div className="date-col">
                        <label>Día</label>
                        <select className="date-select" value={form.dia} onChange={e=>set("dia",e.target.value)}>
                          <option value="">--</option>
                          {dias.map(d=><option key={d} value={d}>{d}</option>)}
                        </select>
                      </div>
                      <div className="date-col">
                        <label>Mes</label>
                        <select className="date-select" value={form.mes} onChange={e=>set("mes",e.target.value)}>
                          <option value="">------</option>
                          {MESES.map((m,i)=><option key={i} value={i+1}>{m}</option>)}
                        </select>
                      </div>
                      <div className="date-col">
                        <label>Año</label>
                        <select className="date-select" value={form.anio} onChange={e=>set("anio",e.target.value)}>
                          <option value="">----</option>
                          {anios.map(a=><option key={a} value={a}>{a}</option>)}
                        </select>
                      </div>
                    </div>
                  </div>

                  <div className="fg">
                    <label className="fl">¿A qué hora llegaste al mundo?</label>
                    <p className="fi-hint" style={{marginBottom:10}}>Si la sabes, escríbela exacta. Si no, elige un rango.</p>
                    <input className="fi" type="time" value={form.horaExacta||""} style={{marginBottom:10}}
                      onChange={e=>{set("horaExacta",e.target.value);if(e.target.value)set("hora","exacta");}}
                      placeholder="ej: 12:30"/>
                    {!form.horaExacta && (
                      <div className="hora-grid">
                        {HORAS.map(h=>(
                          <div key={h.v} className={`hora-opt ${form.hora===h.v?"sel":""}`} onClick={()=>{set("hora",h.v);set("horaExacta","");}}>
                            <span className="hora-icon">{h.icon}</span>
                            <div className="hora-text">
                              <span className="hora-label">{h.label}</span>
                              <span className="hora-range">{h.range}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                    {form.horaExacta && <p className="fi-hint" style={{color:"var(--green)"}}>✓ Hora exacta guardada — mayor precisión en tu perfil</p>}
                  </div>

                  <div className="fg">
                    <label className="fl">¿Dónde naciste?</label>
                    <div className="city-wrap">
                      <input className="fi" placeholder="Escribe tu ciudad..." value={cityQ}
                        onChange={e=>{setCityQ(e.target.value);setCityDrop(true);set("ciudad",e.target.value);}}
                        onFocus={()=>setCityDrop(true)}/>
                      {cityDrop && filteredCities.length>0 && (
                        <div className="city-drop">
                          {filteredCities.map((c,i)=>(
                            <div key={i} className="city-opt" onClick={()=>{
                              set("ciudad",`${c.name}, ${c.country}`);
                              setCityQ(`${c.name}, ${c.country}`);
                              setCityDrop(false);
                            }}>
                              <span className="city-flag">{c.flag}</span>
                              <span className="city-name">{c.name}</span>
                              <span className="city-country">{c.country}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="fnav">
                    <button className="btn-back" onClick={()=>setScreen("landing")}>← Volver</button>
                    <button className="btn-next" disabled={!can1} onClick={()=>setStep(2)}>
                      <span>Continuar →</span>
                    </button>
                  </div>
                </div>
              )}

              {/* PASO 2 */}
              {step===2 && (
                <div>
                  <div className="fg">
                    <label className="fl">¿Cómo eres?</label>
                    <div className="opts">
                      {Q.soy.map(o=><Opt key={o.v} group="soy" v={o.v} l={o.l} icon={o.icon}/>)}
                    </div>
                  </div>
                  <div className="fg" style={{marginTop:18}}>
                    <label className="fl">¿Qué te cuesta más?</label>
                    <div className="opts">
                      {Q.cuesta.map(o=><Opt key={o.v} group="cuesta" v={o.v} l={o.l} icon={o.icon}/>)}
                    </div>
                  </div>
                  <div className="fg" style={{marginTop:18}}>
                    <label className="fl">¿Dónde vives hoy?</label>
                    <div className="city-wrap">
                      <input className="fi" placeholder="Escribe tu ciudad..." value={cityQH}
                        onChange={e=>{setCityQH(e.target.value);setCityDropH(true);set("ciudadHoy",e.target.value);}}
                        onFocus={()=>setCityDropH(true)}/>
                      {cityDropH && filteredCitiesH.length>0 && (
                        <div className="city-drop">
                          {filteredCitiesH.map((c,i)=>(
                            <div key={i} className="city-opt" onClick={()=>{
                              set("ciudadHoy",`${c.name}, ${c.country}`);
                              setCityQH(`${c.name}, ${c.country}`);
                              setCityDropH(false);
                            }}>
                              <span className="city-flag">{c.flag}</span>
                              <span className="city-name">{c.name}</span>
                              <span className="city-country">{c.country}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="fnav">
                    <button className="btn-back" onClick={()=>setStep(1)}>← Atrás</button>
                    <button className="btn-next" disabled={!can2} onClick={()=>setStep(3)}>
                      <span>Continuar →</span>
                    </button>
                  </div>
                </div>
              )}

              {/* PASO 3 */}
              {step===3 && (
                <div>
                  <div className="fg">
                    <label className="fl">¿Qué te dice la gente?</label>
                    <div className="opts">
                      {Q.dicen.map(o=><Opt key={o.v} group="dicen" v={o.v} l={o.l} icon={o.icon}/>)}
                    </div>
                  </div>
                  <div className="fg" style={{marginTop:18}}>
                    <label className="fl">¿Qué buscas hoy?</label>
                    <div className="opts">
                      {Q.busca.map(o=><Opt key={o.v} group="busca" v={o.v} l={o.l} icon={o.icon}/>)}
                    </div>
                  </div>
                  <div className="fg" style={{marginTop:18}}>
                    <label className="fl">¿En qué momento estás?</label>
                    <div className="opts">
                      {Q.momento.map(o=><Opt key={o.v} group="momento" v={o.v} l={o.l} icon={o.icon}/>)}
                    </div>
                  </div>
                  <div className="price-box">
                    <div className="price-n">$3.33</div>
                    <div className="price-l">Perfil completo · Acceso de por vida</div>
                    <div className="price-note">Un solo pago · Sin suscripciones</div>
                  </div>
                  <div className="fnav">
                    <button className="btn-back" onClick={()=>setStep(2)}>← Atrás</button>
                    <button className="btn-next" disabled={!can3} onClick={startLoad}>
                      <span>Generar mi perfil →</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* LOADING */}
      {screen==="loading" && (
        <div className="loading">
          <div className="orb"/>
          <h2 className="load-h">Construyendo tu perfil</h2>
          <p className="load-s">Un momento</p>
          <div className="load-steps">
            {STEPS_LOAD.map((s,i)=>(
              <div key={i} className={`ls ${i===loadStep?"on":i<loadStep?"was":""}`}>
                <div className="ld"/>{s}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* RESULTS */}
      {screen==="results" && perfil && (
        <div className="results">
          <button className="back-btn" onClick={()=>setScreen("landing")}>← Inicio</button>
          <div className="res-top">
            <div className="res-ey">Tu perfil VER·A</div>
            <h1 className="res-name">{form.nombre},<br/><em>este es tu mapa.</em></h1>
            <p className="res-saludo">{perfil.saludo}</p>
          </div>

          <div className="sec">
            <div className="sec-lbl">Tus 3 arquetipos</div>
            <div className="arqs">
              {perfil.arquetipos.map(a=>(
                <div key={a.num} className="arq">
                  <div className="arq-n">Arquetipo {a.num}</div>
                  <div className="arq-name">{a.nombre}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="sec">
            <div className="sec-lbl">Tu energía</div>
            <div className="en-bars">
              {perfil.energia.map(e=>(
                <div key={e.nombre} className="en-bar">
                  <div className="en-lbl">{e.nombre}</div>
                  <div className="en-track"><div className="en-fill" style={{width:`${e.pct}%`}}/></div>
                  <div className="en-pct">{e.pct}%</div>
                </div>
              ))}
            </div>
            <p className="en-desc">{perfil.energiaDesc}</p>
          </div>

          <div className="prop">
            <div className="prop-ey">Tu propósito de vida</div>
            <div className="prop-grid">
              <div><div className="prop-lbl">Tu pasión</div><div className="prop-val">{perfil.proposito.pasion}</div></div>
              <div><div className="prop-lbl">Tu talento</div><div className="prop-val">{perfil.proposito.talento}</div></div>
              <div><div className="prop-lbl">Tu misión</div><div className="prop-val">{perfil.proposito.mision}</div></div>
              <div><div className="prop-lbl">Tu camino</div><div className="prop-val">{perfil.proposito.camino}</div></div>
            </div>
            <p className="prop-frase">"{perfil.proposito.frase}"</p>
          </div>

          <div className="sec">
            <div className="sec-lbl">Tus potencias</div>
            <div className="pot-list">{perfil.potencias.map((p,i)=><div key={i} className="pot">— {p}</div>)}</div>
          </div>

          <div className="sec">
            <div className="sec-lbl">Tus sombras — y cómo convertirlas</div>
            {perfil.sombras.map((s,i)=>(
              <div key={i} className="sombra">
                <div className="som-title">{s.nombre}</div>
                <div className="som-desc">{s.desc}</div>
                <div className="som-trans">→ {s.trans}</div>
                <div className="som-quote">"{s.frase}"</div>
              </div>
            ))}
          </div>

          <div className="vpm">
            <div className="vpm-item"><div className="vpm-lbl">Vocación</div><div className="vpm-val">{perfil.vocacion}</div></div>
            <div className="vpm-item"><div className="vpm-lbl">Pasión</div><div className="vpm-val">{perfil.pasion}</div></div>
            <div className="vpm-item"><div className="vpm-lbl">Misión</div><div className="vpm-val">{perfil.mision_corta}</div></div>
          </div>

          <div className="sec">
            <div className="sec-lbl">Caminos donde puedes brillar</div>
            <div className="carr-grid">
              {perfil.carreras.map((c,i)=>(
                <div key={i} className="carr">
                  <div className="carr-icon">{c.icon}</div>
                  <div className="carr-name">{c.nombre}</div>
                  <div className="carr-why">{c.razon}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="momento">
            <div className="mom-ey">Tu momento actual</div>
            <p className="mom-text">{perfil.momento}</p>
            <p className="mom-action">→ {perfil.momentoAccion}</p>
          </div>

          <div className="sec">
            <div className="sec-lbl">Tus 3 pasos esta semana</div>
            <div className="pasos">
              {perfil.pasos.map((p,i)=>(
                <div key={i} className="paso">
                  <div className="paso-n">{i+1}</div>
                  <div><div className="paso-title">{p.titulo}</div><div className="paso-desc">{p.desc}</div></div>
                </div>
              ))}
            </div>
          </div>

          <div className="frase-final">
            <p className="frase-text">"{perfil.frase}"</p>
            <p className="frase-q">{perfil.pregunta}</p>
          </div>

          <div className="ref">
            <h3 className="ref-title">Comparte lo que descubriste</h3>
            <p className="ref-sub">Si esto te movió algo — imagina lo que puede hacer por alguien que conoces.</p>
            <div className="ref-code">{refCode}</div><br/>
            <button className="btn-ghost" onClick={()=>{navigator.clipboard?.writeText(`vera.app/ref/${refCode}`);setCopied(true);setTimeout(()=>setCopied(false),2000);}}>
              {copied?"✓ Copiado":"Copiar mi enlace"}
            </button>
            <p className="ref-note">Cada persona que usa tu enlace recibe $1.11 de descuento · Tú acumulas $1.11 de crédito</p>
          </div>
        </div>
      )}
    </div>
  );
}
